"""Trainable CPU tissue dynamics and independent scalar reference."""
from .runtime import TissueModel

__all__ = ['TissueModel']
