"""SUPERMiX AETHER's bounded NeuroWave-X research milestone."""

__version__ = "0.1.0"

