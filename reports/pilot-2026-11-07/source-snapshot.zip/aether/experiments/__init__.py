"""Reproducible, bounded communication studies."""
