"""Immutable topology for fixed-size tissue experiments."""
from .topology import Topology

__all__ = ['Topology']
