"""Executed synthetic environments, with explicit observation boundaries."""

